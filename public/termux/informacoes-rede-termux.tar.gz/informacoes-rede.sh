#!/data/data/com.termux/files/usr/bin/sh
# Abre o Informações da rede no Termux com o .NET do próprio Termux
# (pkg install dotnet-host dotnet-runtime-10.0).
pasta=$(dirname "$(readlink -f "$0")")
exec dotnet "$pasta/InformacoesRede.dll" "$@"
